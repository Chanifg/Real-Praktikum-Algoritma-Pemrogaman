pi = 3.14

def luas_lingkaran(r):
  return pi * r * r

def luas_persegi(s):
  return s * s